Integrantes do grupo: 
Alexandre Luis de Oliveira RA 2040482313009 
Tarso de Azevedo RA 2040482313024 
Vinicius Queiroz RA 2040482313012
